﻿namespace CommandPattern.Core.Contracts.Models.Commands
{
    using System;

    public class HelloCommand: ICommand
    {
        public string Execute(string[] args)
        {
            return $"Hello, {args[0]}";
        }
    }
}
