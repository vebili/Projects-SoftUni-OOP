﻿namespace CommandPattern.Core.Contracts.Models
{
    using System;

    public class ExitCommand : ICommand
    {
        public string Execute(string[] args)
        {
            return null;
        }
    }
}
