﻿using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Messages;
using System;
using System.Collections.Generic;

namespace Bakery.Models.Tables
{
    public abstract class Table : ITable
    {
        private List<IBakedFood> bakesdFoods;
        private List<IDrink> drinks;
        private int capacity;
        private int numberOfPeople;

        public Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            TableNumber = tableNumber;
            Capacity = capacity;
            PricePerPerson = pricePerPerson;
            bakesdFoods = new List<IBakedFood>();
            drinks = new List<IDrink>();

        }

        public int TableNumber { get; private set; }

        public int Capacity
        {
            get { return this.capacity; }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidTableCapacity);
                }

                this.capacity = value;
            }
        }

        public int NumberOfPeople
        {
            get { return this.numberOfPeople; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidNumberOfPeople);
                }

                this.numberOfPeople = value;
            }
        }


        public decimal PricePerPerson { get; private set; }

        public bool IsReserved { get; private set; }

        public decimal Price
        {
            get { return PricePerPerson * NumberOfPeople; }
        }

        public void Reserve(int numberOfPeople)
        {
            IsReserved = true;
            NumberOfPeople = numberOfPeople;
        }

        public void OrderFood(IBakedFood food)
        {
            this.bakesdFoods.Add(food);
        }

        public void OrderDrink(IDrink drink)
        {
            this.drinks.Add(drink);
        }

        public decimal GetBill()
        {
            decimal bill = 0;
            foreach (var food in bakesdFoods)
            {
                bill += food.Price;
            }

            foreach (var drink in drinks)
            {
                bill += drink.Price;
            }

            return bill;
        }

        public void Clear()
        {
            bakesdFoods.Clear();
            drinks.Clear();
            numberOfPeople = 0;
            IsReserved = false;
        }

        public string GetFreeTableInfo()
        {
            return $"Return a string with the following format:\r\n" +
                   $"Table: {TableNumber}\r\n" +
                   $"Type: {this.GetType().Name}\r\n" +
                   $"Capacity: {Capacity}\r\n" +
                   $"Price per Person: {PricePerPerson}";
        }
    }
}
