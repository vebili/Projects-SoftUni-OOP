﻿namespace OnlineShop.IO
{
    public interface IReader
    {
        string CustomReadLine();
    }
}