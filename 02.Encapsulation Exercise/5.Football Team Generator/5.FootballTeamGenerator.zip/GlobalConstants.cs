﻿namespace _5.FootballTeamGenerator
{
    public static class GlobalConstants
    {
        public const string InvalidNameErrorMessage = "A name should not be empty.";
    }
}
